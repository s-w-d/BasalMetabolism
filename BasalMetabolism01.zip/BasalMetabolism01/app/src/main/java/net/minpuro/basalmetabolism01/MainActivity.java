package net.minpuro.basalmetabolism01;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;

public class MainActivity extends AppCompatActivity implements RadioGroup.OnCheckedChangeListener, View.OnClickListener {

    RadioGroup radioGroup;
    RadioButton radioButtonMale;
    RadioButton radioButtonFemale;
    EditText editTextAge;
    EditText editTextHeight;
    EditText editTextWeight;
    Button buttonSearch;
    Button buttonCaution;

    int id;
    Intent intent;
    String strSex;
    int iAge;
    double dHeight;
    double dWeight;
    double basalMetabolismMale, basalMetabolismFemale;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        radioGroup = findViewById(R.id.radioGroup);
        radioButtonMale = findViewById(R.id.radioButtonMale);
        radioButtonFemale = findViewById(R.id.radioButtonFemale);
        editTextAge = findViewById(R.id.editTextAge);
        editTextHeight = findViewById(R.id.editTextHeight);
        editTextWeight = findViewById(R.id.editTextWeight);
        buttonSearch = findViewById(R.id.buttonSearch);
        buttonCaution = findViewById(R.id.buttonCaution);

        radioGroup.setOnCheckedChangeListener(this);

        buttonSearch.setOnClickListener(this);
        buttonCaution.setOnClickListener(this);

    }

    @Override
    public void onCheckedChanged(RadioGroup group, int checkedId) {

        if (checkedId == R.id.radioButtonMale) {
            strSex = String.valueOf(radioButtonMale.getText());
        } else if (checkedId == R.id.radioButtonFemale) {
            strSex = String.valueOf(radioButtonFemale.getText());
        }

    }

    @Override
    public void onClick(View v) {

        id = v.getId();

        if (id == R.id.buttonSearch) {
            metabolismCalcu();
        } else if (id == R.id.buttonCaution){
            intent = new Intent(MainActivity.this, CautionActivity.class);
            startActivity(intent);
        }

    }

    private void metabolismCalcu() {

        iAge = Integer.parseInt(String.valueOf(editTextAge.getText()));
        dHeight = Integer.parseInt(String.valueOf(editTextHeight.getText()));
        dWeight = Integer.parseInt(String.valueOf(editTextWeight.getText()));
        //◎男性の場合の計算式
        //男性： 66＋13.7×体重（kg）＋5.0×身長[cm]－6.8×年齢
        basalMetabolismMale = ((66 + (13.7 * dWeight) + (5.0 * dHeight)) - (6.8 * iAge));
        //◎女性の場合の計算式
        //女性：665＋ 9.6×体重（kg）＋1.7×身長[cm]－7.0×年齢
        basalMetabolismFemale = ((665 + (9.6 * dWeight) + (1.7 * dHeight)) - (7.0 * iAge));


        intent = new Intent(MainActivity.this, ResultActivity.class);

//        if (strSex.equals("男性")) {
//            intent.putExtra("basalMetabolismMale", basalMetabolismMale);
//        } else if (strSex.equals("女性")) {
//            intent.putExtra("basalMetabolismFemale", basalMetabolismFemale);
//        }
        intent.putExtra("iAge", iAge);
        intent.putExtra("strSex", strSex);
        intent.putExtra("basalMetabolismMale", basalMetabolismMale);
        intent.putExtra("basalMetabolismFemale", basalMetabolismFemale);
        startActivity(intent);

    }
}
