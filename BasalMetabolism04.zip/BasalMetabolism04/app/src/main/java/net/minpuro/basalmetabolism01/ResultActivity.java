package net.minpuro.basalmetabolism01;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class ResultActivity extends AppCompatActivity implements View.OnClickListener {

    TextView textViewAge;
    TextView textViewSex;
    TextView textViewResult;

    TextView textViewBmi;
    Button buttonBack;
    Button buttonCaution;

    Intent intent;
    int age;
    String sex;
    double resultM, resultF;
    double dBMI;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_result);

        textViewAge = findViewById(R.id.textViewAge);
        textViewSex = findViewById(R.id.textViewSex);
        textViewResult = findViewById(R.id.textViewResult);
        buttonBack = findViewById(R.id.buttonBack);
        buttonCaution = findViewById(R.id.buttonCaution);
        textViewBmi = findViewById(R.id.textViewResultBMI);

        buttonBack.setOnClickListener(this);
        buttonCaution.setOnClickListener(this);

        intent = getIntent();
        Bundle bundle = intent.getExtras();

        age = bundle.getInt("iAge");
        sex = bundle.getString("strSex");
        resultM = bundle.getDouble("basalMetabolismMale");
        resultF = bundle.getDouble("basalMetabolismFemale");
        dBMI = bundle.getDouble("dBMI");


        if (sex.equals("男性")) {
            textViewResult.setText(String.valueOf(resultM));
        } else {
            textViewResult.setText(String.valueOf(resultF));
        }

        textViewAge.setText(String.valueOf(age));
        textViewSex.setText(sex);
        textViewBmi.setText(String.valueOf(dBMI));

    }

    @Override
    public void onClick(View v) {

        int id = v.getId();

        if (id == R.id.buttonBack) {
            finish();
        } else {
            intent = new Intent(ResultActivity.this, CautionActivity.class);
            startActivity(intent);
        }

    }
}
