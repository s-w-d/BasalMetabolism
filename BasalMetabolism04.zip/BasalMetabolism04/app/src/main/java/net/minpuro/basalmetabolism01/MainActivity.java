package net.minpuro.basalmetabolism01;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;

import java.math.BigDecimal;
import java.math.RoundingMode;

public class MainActivity extends AppCompatActivity implements RadioGroup.OnCheckedChangeListener, View.OnClickListener {

    RadioGroup radioGroup;
    RadioButton radioButtonMale;
    RadioButton radioButtonFemale;
    EditText editTextAge;
    EditText editTextHeight;
    EditText editTextWeight;
    Button buttonSearch;
    Button buttonCaution;

    int id;
    Intent intent;
    String strSex;
    int iAge;
    double dHeight, dWeight;
    double basalMetabolismMale, basalMetabolismFemale;
    double dBMI;

    String sAge;
    String sHeight;
    String sWeight;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        radioGroup = findViewById(R.id.radioGroup);
        radioButtonMale = findViewById(R.id.radioButtonMale);
        radioButtonFemale = findViewById(R.id.radioButtonFemale);
        editTextAge = findViewById(R.id.editTextAge);
        editTextHeight = findViewById(R.id.editTextHeight);
        editTextWeight = findViewById(R.id.editTextWeight);
        buttonSearch = findViewById(R.id.buttonSearch);
        buttonCaution = findViewById(R.id.buttonCaution);

        radioGroup.setOnCheckedChangeListener(this);

        buttonSearch.setOnClickListener(this);
        buttonCaution.setOnClickListener(this);

    }

    @Override
    public void onCheckedChanged(RadioGroup group, int checkedId) {

        if (checkedId == R.id.radioButtonMale) {
            strSex = String.valueOf(radioButtonMale.getText());
        } else if (checkedId == R.id.radioButtonFemale) {
            strSex = String.valueOf(radioButtonFemale.getText());
        }

    }

    @Override
    public void onClick(View v) {

        id = v.getId();

        sAge = String.valueOf(editTextAge.getText());
        sHeight = String.valueOf(editTextHeight.getText());
        sWeight = String.valueOf(editTextWeight.getText());

        if (id == R.id.buttonSearch) {
            if (!sAge.equals("") && sAge != null
                    && !sHeight.equals("") && sHeight != null
                    && !sWeight.equals("") && sWeight != null) {
                metabolismCalcu();
            }
        } else if (id == R.id.buttonCaution){
            intent = new Intent(MainActivity.this, CautionActivity.class);
            startActivity(intent);
        }

    }

    private void metabolismCalcu() {

        iAge = Integer.parseInt(sAge);
        dHeight = Integer.parseInt(sHeight);  //単位は[cm]
        dWeight = Integer.parseInt(sWeight);  //単位は[kg]
        //◎男性の場合の基礎代謝の計算式
        //男性： 66＋13.7×体重（kg）＋5.0×身長[cm]－6.8×年齢
        basalMetabolismMale = ((66 + (13.7 * dWeight) + (5.0 * dHeight)) - (6.8 * iAge));
        //◎女性の場合の基礎代謝の計算式
        //女性：665＋ 9.6×体重（kg）＋1.7×身長[cm]－7.0×年齢
        basalMetabolismFemale = ((665 + (9.6 * dWeight) + (1.7 * dHeight)) - (7.0 * iAge));

        //BMIの計算　体重(kg)÷（身長[m]×身長[m]）
        double BMI = dWeight / ((dHeight / 100) * (dHeight / 100));

        BigDecimal bigDecimal = new BigDecimal(String.valueOf(BMI));
        dBMI = bigDecimal.setScale(1, RoundingMode.HALF_UP).doubleValue();


        intent = new Intent(MainActivity.this, ResultActivity.class);

        intent.putExtra("iAge", iAge);
        intent.putExtra("strSex", strSex);
        intent.putExtra("basalMetabolismMale", basalMetabolismMale);
        intent.putExtra("basalMetabolismFemale", basalMetabolismFemale);
        intent.putExtra("dBMI", dBMI);
        startActivity(intent);

    }
}
