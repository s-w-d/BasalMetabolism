package net.minpuro.basalmetabolism01;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class FirstActivity extends AppCompatActivity implements View.OnClickListener {

    Button buttonStart, buttonCaution;

    Intent intent;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_first);

        buttonStart = findViewById(R.id.buttonStart);
        buttonCaution = findViewById(R.id.buttonCaution);

        buttonStart.setOnClickListener(this);
        buttonCaution.setOnClickListener(this);

    }

    @Override
    public void onClick(View v) {

        int id = v.getId();

        if (id == R.id.buttonStart) {
            intent = new Intent(FirstActivity.this, MainActivity.class);
            startActivity(intent);

        } else {
            intent = new Intent(FirstActivity.this, CautionActivity.class);
            startActivity(intent);
        }

    }
}
